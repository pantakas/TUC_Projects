var searchData=
[
  ['cctx',['cctx',['../group__scheduler.html#ga3be3b151b275926dff3fb99bee765eab',1,'cctx():&#160;kernel_sched.c'],['../group__scheduler.html#ga3be3b151b275926dff3fb99bee765eab',1,'cctx():&#160;kernel_sched.c']]],
  ['child_5fexit',['child_exit',['../structprocess__control__block.html#a6bcb52e96fdf96d060af2b11f07d44bd',1,'process_control_block']]],
  ['children_5flist',['children_list',['../structprocess__control__block.html#a79b0dd70bbfff1d7da6ab4cbbd00eb1f',1,'process_control_block']]],
  ['children_5fnode',['children_node',['../structprocess__control__block.html#a5b9aeabcc3d676cda39eb563a4cc5bd9',1,'process_control_block']]],
  ['close',['Close',['../structfile__operations.html#a66cfe706a1a29e3e58c7694dbd801b0f',1,'file_operations']]],
  ['context',['context',['../structthread__control__block.html#a9c107039dffa851dde6edabd6cd3f89c',1,'thread_control_block']]],
  ['core_5flist',['core_list',['../structprogram__arguments.html#ad063b1ce13702392eb2a64792488d505',1,'program_arguments']]],
  ['cpu_5fcore_5fid',['cpu_core_id',['../bios_8h.html#abac58ced7d51f54f2318b326bc991933',1,'bios.h']]],
  ['current_5fthread',['current_thread',['../structcore__control__block.html#aac649db5b9a99e693ed21c7e610834bf',1,'core_control_block']]]
];
