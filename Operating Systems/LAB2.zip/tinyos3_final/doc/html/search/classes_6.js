var searchData=
[
  ['pipe_5fs',['pipe_s',['../structpipe__s.html',1,'']]],
  ['process_5fcontrol_5fblock',['process_control_block',['../structprocess__control__block.html',1,'']]],
  ['process_5fthread_5fcontrol_5fblock',['process_thread_control_block',['../structprocess__thread__control__block.html',1,'']]],
  ['procinfo',['procinfo',['../structprocinfo.html',1,'']]],
  ['program_5farguments',['program_arguments',['../structprogram__arguments.html',1,'']]]
];
