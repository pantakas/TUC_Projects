var searchData=
[
  ['an_20execption_2dlike_20library_2e',['An execption-like library.',['../group__exceptions.html',1,'']]]
];
