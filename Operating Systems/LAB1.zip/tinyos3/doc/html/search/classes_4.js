var searchData=
[
  ['file_5fcontrol_5fblock',['file_control_block',['../structfile__control__block.html',1,'']]],
  ['file_5foperations',['file_operations',['../structfile__operations.html',1,'']]]
];
