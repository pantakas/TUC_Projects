var searchData=
[
  ['read',['Read',['../structfile__operations.html#a59d973a490a6861c498ac9cc9c32dbf5',1,'file_operations::Read()'],['../structpipe__s.html#ad0839b4f9b1fdb0241411952203f18aa',1,'pipe_s::read()']]],
  ['refcount',['refcount',['../structfile__control__block.html#a629271d79f15500a74096ec65a4adedb',1,'file_control_block']]]
];
