
#include "tinyos.h"
#include "kernel_sched.h"
#include "kernel_proc.h"
#include "kernel_threads.h"
#include "kernel_cc.h"
#include "kernel_streams.h"

#include "util.h"


Mutex kernel_mutex = MUTEX_INIT;

/** 
  @brief Create a new thread in the current process.
  */
Tid_t sys_CreateThread(Task task, int argl, void* args)
{
  PCB* cur_proc=CURPROC;
  PTCB* cur_ptcb=xmalloc(sizeof(PTCB));

  initialize_PTCB(cur_ptcb);
  cur_ptcb=(PTCB*)acquire_PTCB();
  cur_ptcb->parent=CURPROC;
  cur_ptcb->main_task=task;
  cur_ptcb->argl=argl;      
  cur_ptcb->args=args;

  rlnode* new_node=(rlnode*)xmalloc(sizeof(rlnode)); //A node to add the new PTCB to the PTCB List
  new_node=rlnode_init(new_node,cur_ptcb);

  (&cur_proc->ptcbs)->ptcb=(PTCB*)acquire_PTCB(); 
  cur_proc->ptcbs=*new_node;
  rlist_push_front(&cur_proc->ptcbs,new_node);
  cur_proc->thread_counter++;
  TCB* newthread=spawn_thread(CURPROC,start_new_thread); //Spawn a thread for our new ptcb node and then ./ Start Thread ./ Exit Thread
  fprintf(stderr, "\nReturn tid meta spawn:%d--",newthread);
  (&cur_proc->ptcbs)->ptcb->thread=newthread;
  (&cur_proc->ptcbs)->ptcb->thread->owner_ptcb=cur_ptcb;  //The new thread's ptcb owner is the the current ptcb
  (&cur_proc->ptcbs)->ptcb->thread->owner_pcb=cur_proc;
  fprintf(stderr, "\nPrin tin wake up:%d--",(&cur_proc->ptcbs)->ptcb->thread);
   wakeup((&cur_proc->ptcbs)->ptcb->thread); //Send signal to the scheduler so that the thread becomes ready
  Mutex_Unlock(&kernel_mutex);
  Tid_t tid=(Tid_t)newthread;
  
  release_PTCB(cur_ptcb);
   fprintf(stderr, "\Prin na to dwsei:%d--",newthread);
	return tid;

}

/**
  @brief Return the Tid of the current thread.
 */
Tid_t sys_ThreadSelf()
{
	return (Tid_t) CURTHREAD;
}

/**
  @brief Join the given thread.
  */
int sys_ThreadJoin(Tid_t tid, int* exitval)
{
  fprintf(stderr, "\nMpike join--");
  rlnode* fptcb=&CURPROC->ptcbs;
  TCB* tcbg=(TCB*)tid;
  PTCB* owner;
  fprintf(stderr, "\npaei gia acq--");
  owner=(PTCB*)acquire_PTCB();
  fprintf(stderr, "\nmeta tin acq--");

  owner=(PTCB*)tcbg->owner_ptcb;

   fprintf(stderr, "\npaei gia x malloc--");

 
  rlnode* node=(rlnode*)xmalloc(sizeof(rlnode));
  rlnode* fail=(rlnode*)xmalloc(sizeof(rlnode));

  fprintf(stderr, "\npaei gia x malloc tou exitval--");


  exitval=xmalloc(sizeof(int));

  fprintf(stderr, "\nmeta to xmaloc exitval--");

  node=rlnode_init(node,owner);
  fail=rlnode_init(fail,owner);

  fprintf(stderr, "\nprin ti find--");
  node=rlist_find(fptcb,owner,fail);
  fprintf(stderr, "\nmeta ti find--");

  if (node!=fail && CURTHREAD->owner_pcb==tcbg->owner_pcb && owner->detached!=1 && owner->exited!=1 && &owner->Jointhreads!=NULL){
  	owner->ref_count++;
    fprintf(stderr, "\npaei gia k wait--");
  	kernel_wait(&owner->Jointhreads, SCHED_USER);
  	fprintf(stderr, "\nekane k wait--");
  	 *exitval=owner->exitval;
    }
  else
  {
      fprintf(stderr, "\npaei gia relase 1--");
      release_PTCB(owner);
      fprintf(stderr, "\negine to release gia -1--");
      return -1;
  }

  fprintf(stderr, "\npaei gia relase 2--");
  release_PTCB(owner);
  fprintf(stderr, "\negine to release gia 0--");
  return 0;
}


/**
  @brief Detach the given thread.
  */
int sys_ThreadDetach(Tid_t tid)

{
  TCB* the_tcb = (TCB*) tid;
  PTCB* ptcb_owner;
  ptcb_owner=(PTCB*)acquire_PTCB();
  ptcb_owner=the_tcb->owner_ptcb;

  
  rlnode* ptcbs = &CURPROC->ptcbs;
  rlnode* node=(rlnode*)xmalloc(sizeof(rlnode));
  rlnode* fail=(rlnode*)xmalloc(sizeof(rlnode));
  node=rlnode_init(node, NULL);
  fail=rlnode_init(fail, NULL);
  node=rlist_find(ptcbs, the_tcb, fail);

  if(node==fail || the_tcb->state==EXITED)
    {
     release_PTCB(ptcb_owner);
     return -1;  
    }
  ptcb_owner->detached=1;
  Cond_Broadcast(&ptcb_owner->Jointhreads);
  release_PTCB(ptcb_owner);
	
  return 0; 
}

/**
  @brief Terminate the current thread.
  */
void sys_ThreadExit(int exitval)
{
  //Broadcasting current's ptcb cv list
  
	fprintf(stderr, "\nSYSTHREADEXIT--");
    TCB* thread=CURTHREAD;
  	fprintf(stderr, "\nPaei gia broad--");
  	CondVar* cv_list = &thread->owner_ptcb->Jointhreads;
  	CURPROC->thread_counter--;
    Cond_Broadcast(cv_list);

  if(&thread->owner_ptcb->ref_count>0)
  {
      thread->owner_ptcb->ref_count--;
      thread->owner_ptcb->exited=1;
  }

/* Bye-bye cruel world */
  kernel_sleep(EXITED, SCHED_USER);		
}