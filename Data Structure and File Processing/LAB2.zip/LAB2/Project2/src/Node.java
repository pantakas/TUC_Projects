
public class Node {
	int key1,key2;
	Node left,right;
	int hight;
	
	public Node(){	// �� �ode ����� �� ���� "�����" ��� ������� ��� ���� �� ���������
		key1=-1;
		key2=-1;
		left=null;
		right=null;
	}
	
	public boolean isexternal(){
		if(this.left==null && this.right==null)
			return true;
		return false;
	}
	
	public boolean isEmpty(){
		if (this.key1==-1 && this.key2==-1)
			return true;
		return false;
	}
	
	public boolean isFull(){
		if(this.key1!=-1 && this.key2!=-1)
			return true;
		return false;
	}

	public int getKey1() {
		return key1;
	}

	public void setKey1(int key1) {
		this.key1 = key1;
	}

	public int getKey2() {
		return key2;
	}

	public void setKey2(int key2) {
		this.key2 = key2;
	}

	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node right) {
		this.right = right;
	}
	
	public int getHight() {
		return hight;
	}

	public void setHight(int hight) {
		this.hight = hight;
	}

}
