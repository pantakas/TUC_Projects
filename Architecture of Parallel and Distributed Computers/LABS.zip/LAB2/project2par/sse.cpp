#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/time.h>
#include <assert.h>
#include <float.h>
#include <xmmintrin.h>

#define MINSNPS_B 5
#define MAXSNPS_E 20


double gettime(void);
float  randpval (void);

double gettime(void)
{
		struct timeval ttime;
		gettimeofday(&ttime , NULL);
		return ttime.tv_sec + ttime.tv_usec * 0.000001;
}

float randpval (void)
{
		int vr = rand();
		int vm = rand()%vr;
		float r = ((float)vm)/(float)vr;
		assert(r>=0.0f && r<=1.00001f);
        return r;
}


int main(int argc, char ** argv)
{
		assert(argc==2);
		assert(atoi(argv[1])>=1);
		
		
		
		
		double timeTotalMainStart = gettime();
		float avgF = 0.0f;
		float maxF = 0.0f;
		float minF = FLT_MAX;
		unsigned int N=(unsigned int)atoi(argv[1]);
		unsigned int iters = 10;
		
		float * mVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(mVec!=NULL);
		float * nVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(nVec!=NULL);
		float * LVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(LVec!=NULL);
		float * RVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(RVec!=NULL);
		float * CVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(CVec!=NULL);
		float * FVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(FVec!=NULL);
		
		float * maxv = (float*)_mm_malloc(sizeof(float),16);
		assert(maxv!=NULL);
		float * minv = (float*)_mm_malloc(sizeof(float),16);
		assert(minv!=NULL);
		float * avgv = (float*)_mm_malloc(sizeof(float),16);
		assert(avgv!=NULL);
		
		memset(maxv,0,sizeof(float)*4);
		memset(minv,0,sizeof(float)*4);
		memset(avgv,0,sizeof(float)*4);
		
    	__m128 *mVec__m128 = (__m128 *) mVec;
    	__m128 *nVec__m128 = (__m128 *) nVec;
    	__m128 *LVec__m128 = (__m128 *) LVec;
    	__m128 *RVec__m128 = (__m128 *) RVec;
    	__m128 *CVec__m128 = (__m128 *) CVec;
    	__m128 *FVec__m128 = (__m128 *) FVec;
    	
    	__m128 *maxv__m128 = (__m128 *) maxv;
    	__m128 *minv__m128 = (__m128 *) minv;
    	__m128 *avgv__m128 = (__m128 *) avgv;
		
		for(unsigned int i=0;i<N;i++)
			{
				mVec[i] = (float)(MINSNPS_B+rand()%MAXSNPS_E);
				nVec[i] = (float)(MINSNPS_B+rand()%MAXSNPS_E);
				LVec[i] = randpval()*mVec[i];
				RVec[i] = randpval()*nVec[i];
				CVec[i] = randpval()*mVec[i]*nVec[i];
				FVec[i] = 0.0;
				assert(mVec[i]>=MINSNPS_B && mVec[i]<=(MINSNPS_B+MAXSNPS_E));
				assert(nVec[i]>=MINSNPS_B && nVec[i]<=(MINSNPS_B+MAXSNPS_E));
				assert(LVec[i]>0.0f && LVec[i]<=1.0f*mVec[i]);
				assert(RVec[i]>0.0f && RVec[i]<=1.0f*nVec[i]);
				assert(CVec[i]>0.0f && CVec[i]<=1.0f*mVec[i]*nVec[i]);
			}
		
		
		__m128 numerator;
		__m128 num_numerator;
    	__m128 num_denumerator;
    	__m128 num_den_var1;
   		__m128 num_den_var2;
    	__m128 denumerator;
		__m128 den_numerator;
    	__m128 den_denumerator;
    	
    	const __m128 zero = _mm_set1_ps(0.f);
    	const __m128 one  = _mm_set1_ps(1.f);
    	const __m128 two  = _mm_set1_ps(2.f);
    	const __m128 four = _mm_set1_ps(4.f);
    	const __m128 Nval = _mm_set1_ps((float)N);
    	const __m128 pp1  = _mm_set1_ps(0.01f);
    	
    	
		double timeOmegaTotalStart = gettime();
    	for(int i=0;i<iters;i++){
			avgF = 0.0f;
		    maxF = 0.0f;
		    minF = FLT_MAX;
		    
		    for(int j=0;j<N/4;j++){
		    	//----------------------num-----------------------
		    	//L+R
				num_numerator=_mm_add_ps(LVec__m128[j],RVec__m128[j]);
				
				//(m*(m-1)/2
				num_den_var1=_mm_sub_ps(mVec__m128[j],one);
				num_den_var1=_mm_mul_ps(mVec__m128[j],num_den_var1);
				num_den_var1=_mm_div_ps(num_den_var1,two);
				
				
				//n*(n-1)/2
				num_den_var2=_mm_sub_ps(nVec__m128[j],one);
				num_den_var2=_mm_mul_ps(nVec__m128[j],num_den_var2);
				num_den_var2=_mm_div_ps(num_den_var2,two);
				
				
				//(m*(m-1)/2+n*(n-10)/2
				num_denumerator=_mm_sub_ps(num_den_var1,num_den_var2);
				
				//(L+R)/[(m*(m-1)/2+n*((n-10)/2)]
				numerator=_mm_div_ps(num_numerator,num_denumerator);
				
				//----------------------den-----------------------
				//C-L
				den_numerator=_mm_sub_ps(CVec__m128[j],LVec__m128[j]);
				
				//C-L-R
				den_numerator=_mm_sub_ps(den_numerator,RVec__m128[j]);
				
				//m*n
				den_denumerator=_mm_mul_ps(mVec__m128[j],nVec__m128[j]);
				
				//(C-L-R)/(m*n)
				denumerator=_mm_div_ps(den_numerator,den_denumerator);
				
				//----------------------omega---------------------
				//den+0.01
				FVec__m128[j]=_mm_add_ps(denumerator,pp1);
				
				//num/(den+0.01)
				FVec__m128[j]=_mm_div_ps(numerator,FVec__m128[j]);
				//--------------------------------------------------
				
				*maxv__m128	= _mm_max_ps(*maxv__m128,FVec__m128[j]);	
				*minv__m128 = _mm_min_ps(*minv__m128,FVec__m128[j]);
				*avgv__m128 = _mm_add_ps(*avgv__m128,FVec__m128[j]);
				
				printf("maxv:%f\nminv:%f\navg:%f\nFVec:%f",*maxv__m128,*minv__m128,*avgv__m128,FVec__m128[j]);;
				
			}
			
			//FindMax			
			maxF=maxv[0];
			maxF=maxv[1]>maxF ? maxv[1] : maxF;
			maxF=maxv[2]>maxF ? maxv[2] : maxF;
			maxF=maxv[3]>maxF ? maxv[3] : maxF;
			
			//FindMin
			minF=minv[0];	
			minF=minv[1]>minF ? minF : minv[1];
			minF=minv[2]>minF ? minF : minv[2];
			minF=minv[3]>minF ? minF : minv[3];
			
			//FindAvg
			avgF=avgv[0]+avgv[1]+avgv[2]+avgv[3];
			avgF=avgF/N;
			
			//Uncalculated values when N%4!=0
			
			for (int l = N - (N%4); l < N; l++) {
				
            	float num_0 = LVec[l] + RVec[l];
            	float num_1 = mVec[l] * (mVec[l] - 1.0f) / 2.0f;
            	float num_2 = nVec[l] * (nVec[l] - 1.0f) / 2.0f;
            	float num = num_0 / (num_1 + num_2);
            	
            	float den_0 = CVec[l] - LVec[l] - RVec[l];
            	float den_1 = mVec[l] * nVec[l];
            	float den = den_0 / den_1;
            
            	FVec[l] = num / (den + 0.01f);
            	
            	maxF = FVec[l] > maxF ? FVec[l] : maxF;
        		minF = FVec[l]<minF?FVec[l]:minF;
        		avgF += FVec[l]/N;
			}
			
			double timeOmegaTotal = gettime()-timeOmegaTotalStart;
			double timeTotalMainStop = gettime();
			
			printf("Omega time %fs - Total time %fs - Min %e - Max %e - Avg %e\n",
			timeOmegaTotal/iters, timeTotalMainStop-timeTotalMainStart, (double)minF, (double)maxF,(double)avgF);	
			
			
			_mm_free(mVec);
    		_mm_free(nVec);
   			_mm_free(LVec);
    		_mm_free(RVec);
    		_mm_free(CVec);
    		_mm_free(FVec);
    		_mm_free(minv);
    		_mm_free(maxv);
    		_mm_free(avgv);
		}
}

