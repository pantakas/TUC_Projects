#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include <string.h>
#include <sys/time.h>
#include <assert.h>
#include <float.h>
#include <xmmintrin.h>
#include <pthread.h>
#include <unistd.h>
//#include <mpi.h>

#define MINSNPS_B 5
#define MAXSNPS_E 20
#define EXIT 127
#define BUSYWAIT -1


__m128 *mVec__m128;
__m128 *nVec__m128;
__m128 *LVec__m128;
__m128 *RVec__m128;
__m128 *CVec__m128;
__m128 *FVec__m128;
    	
__m128 *maxv__m128;
__m128 *minv__m128;
__m128 *avgv__m128;

__m128 numerator;
__m128 denumerator;


float * mVec;
float * nVec;
float * FVec;
float * CVec;
float * RVec;
float * LVec;
float * minv;
float * avgv;
float * maxv;

static int count;
int value,threads=0;
static bool sense;

static pthread_t * workerThread;
static pthread_barrier_t barrier;

static void pinToCore(int);
void calculatevalues(void);
__m128 calculatenumerator(void);
__m128 calculatedenumerator(void);
void calculateomma();
void sense_reversal_barrier (int,int); 

typedef struct 
{
	int id;
	int total;
	int barrier;
	int operation;
	int value;


} threadData_t;

typedef struct localsense_t {
	bool lsense;
}localsense_t;

static localsense_t *localsense_list=NULL;

double gettime(void);
float  randpval (void);
void terminateWorkerThreads(pthread_t * workerhreadTL, threadData_t * threadData);



double gettime(void)
{
		struct timeval ttime;
		gettimeofday(&ttime , NULL);
		return ttime.tv_sec + ttime.tv_usec * 0.000001;
}

float randpval (void)
{
		int vr = rand();
		int vm = rand()%vr;
		float r = ((float)vm)/(float)vr;
		assert(r>=0.0f && r<=1.00001f);
        return r;
}


void * thread (void * x)
{
	threadData_t * currentThread = (threadData_t *) x;

	int tid = currentThread->id;
	pinToCore(tid);
	
	while(1){
		if(currentThread->operation==EXIT)
			return NULL;
		switch(currentThread->operation)
		{
			case 0:
			  calculatevalues();
			  break;
			case 1:
			  calculatenumerator();
			  break;
			case 2:
				calculatedenumerator();
				break;
			case 3:
				calculateomma();
				break;
			default://EXIT
				return NULL;
		}
		currentThread->operation=BUSYWAIT;
		sense_reversal_barrier(tid, threads);
 		pthread_barrier_wait(&barrier);
 		currentThread->barrier=1;			
		while(currentThread->barrier==1) __sync_synchronize();
		
	}
	
}

void sense_reversal_barrier (int tid, int num_threads) 
{
	int threadno = tid;
	localsense_list[threadno].lsense = !localsense_list[threadno].lsense;

	if (__sync_fetch_and_sub (&count, 1) == 1) {
		count = num_threads;
		sense = localsense_list[threadno].lsense;
	}
	else {
		while(sense != localsense_list[threadno].lsense) __sync_synchronize();
	}
}

static void pinToCore(int tid)
{
	cpu_set_t cpuset;
         
	CPU_ZERO(&cpuset);    
	CPU_SET(tid, &cpuset);
	if(pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset) != 0)
	{
		fprintf(stdout, "\n ERROR: Please specify a number of threads that is smaller or equal");
		fprintf(stdout, "\n        to the number of available physical cores (%d).\n\n",tid);
		exit(0);
	}
}

void terminateWorkerThreads(pthread_t * workerThreadL, threadData_t * threadData)
{
	int i, threads=threadData[0].total;
	
	for(i=0;i<threads;i++)
		threadData[i].operation = EXIT;			

	for(i=1;i<threads;i++)
		pthread_join(workerThreadL[i-1],NULL);
}

void initializeThreadData(threadData_t * cur, int i, int threads)
{
	cur->id=i;
	cur->total=threads;
	cur->barrier=0;
	cur->operation=BUSYWAIT;
	cur->value=value;
}

int main(int argc, char ** argv)
{
		assert(argc==3);
		assert(atoi(argv[1])>=1);
		assert(atoi(argv[2])>=1);
		
    	MPI_Init(NULL, NULL);
    	int world_size;
    	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    	int world_rank;
    	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
		
		unsigned int threads=atoi(argv[2]);
		unsigned int N=(unsigned int)atoi(argv[1]);
		
		int s = pthread_barrier_init(&barrier, NULL, (unsigned int)threads);
		assert(s == 0);
		
		workerThread = NULL; 
		workerThread = (pthread_t *) malloc (sizeof(pthread_t)*((unsigned long)(threads-1)));
		
		threadData_t * threadData = (threadData_t *) malloc (sizeof(threadData_t)*((unsigned long)threads));
		assert(threadData!=NULL);

		double timeTotalMainStart = gettime();
		float avgF = 0.0f;
		float maxF = 0.0f;
		float minF = FLT_MAX;
		unsigned int iters = 10;
		
		mVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(mVec!=NULL);
		nVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(nVec!=NULL);
		LVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(LVec!=NULL);
		RVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(RVec!=NULL);
		CVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(CVec!=NULL);
		FVec = (float*)_mm_malloc(sizeof(float)*N,16);
		assert(FVec!=NULL);
		
		maxv = (float*)_mm_malloc(sizeof(float),16);
		assert(maxv!=NULL);
		minv = (float*)_mm_malloc(sizeof(float),16);
		assert(minv!=NULL);
		avgv = (float*)_mm_malloc(sizeof(float),16);
		assert(avgv!=NULL);
		
		memset(maxv,0,sizeof(float)*4);
		memset(minv,0,sizeof(float)*4);
		memset(avgv,0,sizeof(float)*4);
		
        mVec__m128 = (__m128 *) mVec;
		nVec__m128 = (__m128 *) nVec;
		LVec__m128 = (__m128 *) LVec;
		RVec__m128 = (__m128 *) RVec;
		CVec__m128 = (__m128 *) CVec;
		FVec__m128 = (__m128 *) FVec;
    	
		maxv__m128 = (__m128 *) maxv;
		minv__m128 = (__m128 *) minv;
		avgv__m128 = (__m128 *) avgv;
		
		
		 int processSize = (N/4) / world_size;
    	 int start = processSize*world_size;
         int end = N/4;
    	 
    	 if (!world_rank)
    		for(int i=0;i<threads;i++)
		    	initializeThreadData(&threadData[i],i,threads);
    	 if (!world_rank)
			for(int i=1;i<threads;i++)
				pthread_create (&workerThread[i-1], NULL, thread, (void *) (&threadData[i]));
		
		
    	
    	//-----------calculatevalues--------------------   
		value=N;	
    	calculatevalues();
		
		//-----------------------------------------------
		
		__m128 numerator;
    	__m128 denumerator;
    	
    	const __m128 zero = _mm_set1_ps(0.f);
    	const __m128 four = _mm_set1_ps(4.f);
    	const __m128 Nval = _mm_set1_ps((float)N);
    	value=N;
		double timeOmegaTotalStart = gettime();
			avgF = 0.0f;
		    maxF = 0.0f;
		    minF = FLT_MAX;
		    
		    for(int j=start;j<end;j++){
		    	value=j;
		    	//----------------------num-----------------------
		     	
		    	numerator=calculatenumerator();
		    	
				//----------------------den-----------------------
				
				denumerator=calculatedenumerator();
				
				//----------------------omega---------------------
				
				calculateomma();
				
			}
			
			//FindMax			
			maxF=maxv[0];
			maxF=maxv[1]>maxF ? maxv[1] : maxF;
			maxF=maxv[2]>maxF ? maxv[2] : maxF;
			maxF=maxv[3]>maxF ? maxv[3] : maxF;
			
			//FindMin
			minF=minv[0];	
			minF=minv[1]>minF ? minF : minv[1];
			minF=minv[2]>minF ? minF : minv[2];
			minF=minv[3]>minF ? minF : minv[3];
			
			//FindAvg
			avgF=avgv[0]+avgv[1]+avgv[2]+avgv[3];
			avgF=avgF/N;
			
			//Uncalculated values when N%4!=0
			
			for (int l = N - (N%4); l < N; l++) {
				
            	float num_0 = LVec[l] + RVec[l];
            	float num_1 = mVec[l] * (mVec[l] - 1.0f) / 2.0f;
            	float num_2 = nVec[l] * (nVec[l] - 1.0f) / 2.0f;
            	float num = num_0 / (num_1 + num_2);
            	
            	float den_0 = CVec[l] - LVec[l] - RVec[l];
            	float den_1 = mVec[l] * nVec[l];
            	float den = den_0 / den_1;
            
            	FVec[l] = num / (den + 0.01f);
            	
            	maxF = FVec[l] > maxF ? FVec[l] : maxF;
        		minF = FVec[l]<minF?FVec[l]:minF;
        		avgF += FVec[l]/N;
			}
			
			double timeOmegaTotal = gettime()-timeOmegaTotalStart;
			double timeTotalMainStop = gettime();
			
			printf("Omega time %fs - Total time %fs - Min %e - Max %e - Avg %e\n",
			timeOmegaTotal/iters, timeTotalMainStop-timeTotalMainStart, (double)minF, (double)maxF,(double)avgF);	
			
			float *processMax = world_rank ? NULL : (float *) malloc(sizeof(float) * world_size);
    		MPI_Gather(&maxF, 1, MPI_FLOAT, processMax, 1, MPI_FLOAT, 0, MPI_COMM_WORLD);

    		// Finalize the MPI environment.
    		MPI_Barrier(MPI_COMM_WORLD);
    		MPI_Finalize();

    		if (!world_rank) {
        		float globalMax = 0;
        		for (int i = 0; i < world_size; i++) {
           	 	globalMax = globalMax < processMax[i] ? processMax[i] : globalMax;
        	}
        // printf("Time %f Max %f\n", timeTotal / iters, globalMax);
    }
    free(processMax);
			
			_mm_free(mVec);
    		_mm_free(nVec);
   			_mm_free(LVec);
    		_mm_free(RVec);
    		_mm_free(CVec);
    		_mm_free(FVec);
    		_mm_free(minv);
    		_mm_free(maxv);
    		_mm_free(avgv);
		
		
		terminateWorkerThreads(workerThread,threadData);
		
		if(threadData!=NULL)
	    	free(threadData);
		threadData = NULL;
}

__m128 calculatenumerator(){
		
		__m128 num_numerator;
    	__m128 num_denumerator;
    	__m128 num_den_var1;
   		__m128 num_den_var2;
   		
   		int j=value;
    	const __m128 one  = _mm_set1_ps(1.f);
    	const __m128 two  = _mm_set1_ps(2.f);
   		
   		//L+R
		num_numerator=_mm_add_ps(LVec__m128[j],RVec__m128[j]);
				
		//(m*(m-1)/2
		num_den_var1=_mm_sub_ps(mVec__m128[j],one);
		num_den_var1=_mm_mul_ps(mVec__m128[j],num_den_var1);
		num_den_var1=_mm_div_ps(num_den_var1,two);
			
				
		//n*(n-1)/2
		num_den_var2=_mm_sub_ps(nVec__m128[j],one);
		num_den_var2=_mm_mul_ps(nVec__m128[j],num_den_var2);
		num_den_var2=_mm_div_ps(num_den_var2,two);
				
				
		//(m*(m-1)/2+n*(n-10)/2
		num_denumerator=_mm_sub_ps(num_den_var1,num_den_var2);
		
		//(L+R)/[(m*(m-1)/2+n*((n-10)/2)]
		return _mm_div_ps(num_numerator,num_denumerator);
				
}

__m128 calculatedenumerator()
{
    	int j=value;
		__m128 den_numerator;
		__m128 den_denumerator;
    	//C-L
		den_numerator=_mm_sub_ps(CVec__m128[j],LVec__m128[j]);
		
		//C-L-R
		den_numerator=_mm_sub_ps(den_numerator,RVec__m128[j]);
		
		//m*n
		den_denumerator=_mm_mul_ps(mVec__m128[j],nVec__m128[j]);
		
		//(C-L-R)/(m*n)
		return _mm_div_ps(den_numerator,den_denumerator);
    	
}

void calculateomma(){
		int j=value;
		
    	const __m128 pp1  = _mm_set1_ps(0.01f);
    	
		//den+0.01
		FVec__m128[j]=_mm_add_ps(denumerator,pp1);
		
		//num/(den+0.01)
		FVec__m128[j]=_mm_div_ps(numerator,FVec__m128[j]);
		//--------------------------------------------------
		
		*maxv__m128	= _mm_max_ps(*maxv__m128,FVec__m128[j]);	
		*minv__m128 = _mm_min_ps(*minv__m128,FVec__m128[j]);
		*avgv__m128 = _mm_add_ps(*avgv__m128,FVec__m128[j]);
		
		printf("maxv:%f\nminv:%f\navg:%f\nFVec:%f",*maxv__m128,*minv__m128,*avgv__m128,FVec__m128[j]);;
}

void calculatevalues()
{
		int N=value;
		for(unsigned int i=0;i<N;i++)
			{
				mVec[i] = (float)(MINSNPS_B+rand()%MAXSNPS_E);
				nVec[i] = (float)(MINSNPS_B+rand()%MAXSNPS_E);
				LVec[i] = randpval()*mVec[i];
				RVec[i] = randpval()*nVec[i];
				CVec[i] = randpval()*mVec[i]*nVec[i];
				FVec[i] = 0.0;
				assert(mVec[i]>=MINSNPS_B && mVec[i]<=(MINSNPS_B+MAXSNPS_E));
				assert(nVec[i]>=MINSNPS_B && nVec[i]<=(MINSNPS_B+MAXSNPS_E));
				assert(LVec[i]>0.0f && LVec[i]<=1.0f*mVec[i]);
				assert(RVec[i]>0.0f && RVec[i]<=1.0f*nVec[i]);
				assert(CVec[i]>0.0f && CVec[i]<=1.0f*mVec[i]*nVec[i]);
			}
}

