//Panagiotis Takas 2013030010 Antonis Sartzetakis 2014030095 
//Prwto Project Arxitektoniki Parallilwn kai Katanemimenwn Sustimatwn 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>  
#include <time.h>
#include <omp.h>
#define sizeofline 256


//Global Variables Decleration-------------------------------------------------------------------------------------------------------------
char *name,*path;
int match,mismatch,gap,numofthreads;
int   era,erb,erc=0;
double ere,erf;
FILE  *fp,*fp2;
double time_spent;

//Struct to fill my scoringmatrix(H)-------------------------------------------------------------------------------------------------------

typedef struct valuesofmatrix{
	struct valuesofmatrix *previous;
	int ci;
	int cj;
	int value;
}matrixvar;

//Functions Decleration--------------------------------------------------------------------------------------------------------------------

//void initializeNIMMG(char **argv);
void openfile(void);
void createfile(void);
void getqds(char qd,char* need);
void getinfos(void);
void initializeNIMMG(char **argv,int argc);
void fillscoringmatrix(char* qvars,char* dvars,int qs,int ds);
void printquestions(void);
int tracebackrecursions(matrixvar *scoringmatrix,char *dvars,char *qvars,int score,int stop,int times,int max,int matchcounter);
int findmax(int a,int b,int c,int d,matrixvar *scoringmatrix,matrixvar *scoringmatrix2,matrixvar *scoringmatrix3,matrixvar *scoringmatrix4);
int getnextnum(void);

//------------------------------------------------------------------------------------------------------------------------------------------
int main(int argc,char* argv[]){
	clock_t begin = clock();
	initializeNIMMG(argv,argc);	
	createfile();
	openfile();
	getinfos();
	fclose(fp);
	fclose(fp2);
	clock_t end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printquestions();
	
}

void printquestions(){
	
	printf("\nA)Number of pairs:%d\n",era);
	printf("B)Number of cells:%d\n",erb);
	printf("C)Number of traceback steps:%d\n",erc);
	printf("D)Execution time :%lf\n",time_spent);
	printf("E)Cells calculation time:%lf\n",ere);
	printf("F)Total traceback time:%lf\n",erf);
	printf("G)CUPS(execution time):%lf\n",erb/time_spent);
	printf("H)CUPS(cell calculation time):%lf",ere/erb);
}

void initializeNIMMG(char *argv[],int argc){
	for(int i=2;i<=12;i+=2){
		if(strcmp(argv[i-1],"-name")==0)
			name=argv[i];
		else if(strcmp(argv[i-1],"-input")==0)
			path=argv[i];
		else if(strcmp(argv[i-1],"-match")==0)
			match=atoi(argv[i]);
		else if(strcmp(argv[i-1],"-mismatch")==0)
			mismatch=atoi(argv[i]);
		else if(strcmp(argv[i-1],"-gap")==0)
			gap=atoi(argv[i]);
		else if(strcmp(argv[i-1],"-threads")==0)
			numofthreads=atoi(argv[i]);
	}
}

void openfile(){
	fp=fopen(path,"r");
	if(fp==NULL)
	   printf("File does not exist");
}



void createfile(){
	char help[20],help1[5];
	strcpy(help1,"_OMP");
	strcpy(help,"Report_");
	strcat(help,name);
	strcat(help,help1);
	fp2=fopen(help,"w");
	if(fp2==NULL)
	   printf("File can not be created");
}

int tracebackrecursions(matrixvar *scoringmatrix,char *dvars,char *qvars,int score,int stop,int times,int max,int nofmatch){
	erc++;
	times++;
	if(scoringmatrix->value==0 || scoringmatrix->ci==0 || scoringmatrix->cj==0 || times>max){
		
		fprintf(fp2, "\nMatch %d[Score:%d,Start:%d,Stop:%d]\n",nofmatch,score,scoringmatrix->cj,stop);
		
		if(dvars[scoringmatrix->cj-1]==qvars[scoringmatrix->ci-1])
			fprintf(fp2, "%c\n",qvars[scoringmatrix->cj-1]);
		else
			fprintf(fp2, "-");	
		return 0;
	}
		
	tracebackrecursions(scoringmatrix->previous,dvars,qvars,score,stop,times,max,nofmatch);
	if(scoringmatrix->value<scoringmatrix->previous->value){
		score=score+gap;
		fprintf(fp2,"-",dvars[scoringmatrix->cj-1]);
	}
	
	if(scoringmatrix->value>=scoringmatrix->previous->value){
		score=score+match;
		fprintf(fp2, "%c",dvars[scoringmatrix->cj-1]);
	}
	
}


int findmax(int a,int b,int c,int d,matrixvar *scoringmatrix,matrixvar *scoringmatrix2,matrixvar *scoringmatrix3,matrixvar *scoringmatrix4){
    int max = (a > b? a : b);   
    max = (c > d? (c > max? c : max) : (d > max? d : max));
    
    if(a==max){
    	scoringmatrix->previous=scoringmatrix2;
    }
    else if(b==max){
    	scoringmatrix->previous=scoringmatrix3;
	}
	else if(c==max){
		scoringmatrix->previous=scoringmatrix4;
	}
	else{
		scoringmatrix->previous=scoringmatrix;
 }

	return max;
}

void fillscoringmatrix(char* qvars,char* dvars,int qs,int ds){
	int th_id;
	omp_set_num_threads(numofthreads);
	#pragma omp parallel private(th_id)
	{
	th_id=omp_get_thread_num();
	matrixvar *scoringmatrix=(matrixvar *)malloc((qs+1) * (ds+1) * sizeof(matrixvar)); ;
	
	int a,b,c,d;
	int max=0;
	matrixvar maxelement;
	for(int i=0;i<qs+1;i++)
		for(int j=0;j<ds+1;j++){
			(scoringmatrix + i*ds + j)->value=0;
			(scoringmatrix + i*ds + j)->ci=i;
			(scoringmatrix + i*ds + j)->cj=j;
		}
	int scoreij=match;
	clock_t begin = clock();
	#pragma omp barrier
	for(int i=1;i<qs+1;i++){
		for(int j=1;j<ds+1;j++){
			
			if(qvars[i-1]!=dvars[j-1])
				scoreij=mismatch;
			(scoringmatrix + i*ds + j)->value=findmax((scoringmatrix + (i-1)*ds + (j-1))->value+scoreij,(scoringmatrix + (i-1)*ds + j)->value+mismatch,(scoringmatrix + i*ds + (j-1))->value+mismatch,0,(scoringmatrix + i*ds + j),(scoringmatrix + (i-1)*ds + (j-1)),(scoringmatrix + (i-1)*ds + j),(scoringmatrix + i*ds + j));
			scoreij=match;
			
			if((scoringmatrix + i*ds + j)->value>max){
				max=(scoringmatrix + i*ds + j)->value;
				maxelement=*(scoringmatrix + i*ds + j);
			}
		}
	  }
	#pragma omp barrier
	clock_t end = clock();
	ere += (double)(end - begin) / CLOCKS_PER_SEC;
	begin = clock();
	int matchcounter=0;
	for(int i=1;i<qs+1;i++){
		for(int j=1;j<ds+1;j++){
			if((scoringmatrix + i*ds + j)->value==maxelement.value){
				matchcounter++;
				fprintf(fp2, "\n");
				tracebackrecursions((scoringmatrix + i*ds + j),dvars,qvars,((scoringmatrix + i*ds + j)->value+1)*match,(scoringmatrix + i*ds + j)->cj,0,(scoringmatrix + i*ds + j)->value,matchcounter);
			}
		}
	}
	end = clock();
	erf+=(double)(end - begin) / CLOCKS_PER_SEC;
	free(scoringmatrix);}
}


int getnextnum(){
	
	char* dn=(char*) malloc(sizeofline * sizeof(char));
	char* wr=(char*) malloc(sizeofline * sizeof(char));
	int i;
	while(fgetc(fp)!=':'){
		
	}
	fscanf(fp," ");
	fscanf(fp,"%[^\n]",wr);
	i=atoi(wr);
	free(dn);
	free(wr);
	return i;
}

void getqds(char* need,int num,char qd){
	char   flag;
	int i=0;
	fgetc(fp);
    while(EOF!=(flag=fgetc(fp)) && i<num && flag!=qd){
    	if(flag!='\t' && flag!='\n' && flag!=':'){
	    	fprintf(fp2, "%c",flag);
    		need[i] = flag;
    		need[i+1]='\0';
    		i++;
		}
	}
}

void getinfos(){
	int pairs,qs,ds;
	char* qvar,dvar;	
	pairs=getnextnum();
	getnextnum();
	qs=getnextnum();
	ds=getnextnum();
	era+=pairs;

	for(int j=0;j<pairs;j++){
		char* qvar=(char*) malloc(qs * sizeof(char));
		char* dvar=(char*) malloc(ds * sizeof(char));
		char* dn3=(char*) malloc(sizeofline * sizeof(char));
		erb+=(strlen(qvar)+1)*(strlen(dvar)+1);
		fscanf(fp,"%[^Q]",dn3);
		fprintf(fp2, "\n\nQ: ");	
		getqds(qvar,qs,'D');
		fprintf(fp2, "\nD: ");
		getqds(dvar,ds,'Q');
		fprintf(fp2, "\n");	
		fillscoringmatrix(qvar,dvar,strlen(qvar),strlen(dvar));
        free(qvar);
        free(dvar);
        free(dn3);
	}
}

