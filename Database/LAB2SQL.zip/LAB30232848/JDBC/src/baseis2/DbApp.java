package baseis2;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;
import java.io.BufferedReader;

public class DbApp {
    static Connection conn;
	
public DbApp() {
		conn = null;
	}
	
public static void main(String[] args){
		printmenu();
		Scanner answer=new Scanner(System.in);
		int epilogi;
		epilogi=answer.nextInt();
		while(epilogi!=1){
			System.out.println("You have to connect to the database first!");
			epilogi=answer.nextInt();
		}
		leitourgies(1);
		do{
			System.out.println("Please choose a valiable option");
		 	epilogi=answer.nextInt();
		 	if(epilogi!=7 && epilogi>0 && epilogi<8)
		    leitourgies(epilogi);
		}while(epilogi!=7);
		
}
	
public static void printmenu(){
		System.out.println("Press :\n1)To connect or to commit\n"
				+ "2)To insert a bachelor\n"
				+ "3)To print the grades of a student (through A.M. and course code)\n"
				+ "4)To change the grade of a student (through A.M. and serial execution code of a course)\n"
				+ "5)To search for a member (Professor,Lab staff,Student) through the first letters of surname\n"
				+ "6)To view all the grades of a student through A.M.\n"
		        + "7)To exit");
	}

public static void leitourgies(int epilogi){
	switch(epilogi){
		case 1: connect();
				db_commit();
				break;
		case 2:insertDiploma();
		       db_commit();
		       break;
		case 3:searchgrades();
		       break;
		case 4:updategrade();
               db_commit();
				break;
		case 5:searchperson();
				break;
		case 6:searchgradesall();
				break;
	}
}

public static void connect () {
	try {
 		Class.forName("org.postgresql.Driver");
 		conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/"+"teliko","postgres","panos1995");
 		System.out.println("Connection Established!");
 		conn.setAutoCommit(false);
	} catch(Exception e) {
        e.printStackTrace();
	}
}

public static void db_commit() {
	try {
		conn.commit();
	} catch (SQLException e) {
		e.printStackTrace();
	}
}

public static void insertDiploma() {
	CallableStatement stmt;
	Scanner times=new Scanner(System.in);
	String am,amka1,amka2,amka3;
	boolean exists=false;
	try {
		String procedure="{call insertdiploma(?,?,?,?)}";
		stmt = conn.prepareCall(procedure);
		System.out.println("Please enter the am of the Student");
		am=times.next();
		exists=validamka(am,1);
		if(exists==true){
		  stmt.setString(1,am);
		  System.out.println("Please enter the amka of the supervisor Professor ");
		  amka1=times.next();
		  exists=validamka(amka1,2);
		  if(exists==true){
			  System.out.println("Please enter the amka of the second Professor ");
			  amka2=times.next();
			  exists=validamka(amka2,2);
			  if(exists==true){
				  System.out.println("Please enter the amka of the third Professor ");
				  amka3=times.next();
				  exists=validamka(amka3,2);
			     if (exists==true){
				  stmt.setString(1, am);
				  stmt.setString(2, amka1);
				  stmt.setString(3, amka2);
				  stmt.setString(4, amka3);
				  stmt.execute();
			    }
				  
			}
		  }
		}	
	}
	 catch (SQLException e) {
		e.printStackTrace();
	}	
   if(exists==false)
	   System.out.println("You have entered invalid amka or am");
}

public static boolean validamka(String am,int who) {
	boolean exists=false;
	try {
		Statement ststud = conn.createStatement();
		Statement stprof = conn.createStatement();
		String query = "SELECT am FROM \"Student\"";
		String query1 = "SELECT amka FROM \"Professor\"";
		ResultSet allstud = ststud.executeQuery(query);
		ResultSet allprof = stprof.executeQuery(query1);
		switch (who){
			case 1:
				while(allstud.next()){
					if(am.equals(allstud.getString("am"))){
						System.out.println("Valid am of Student");
						exists=true;
					}
				}
			case 2:
				while(allprof.next()){
					if(am.equals(allprof.getString("amka"))){
						System.out.println("Valid amka of Professor");
						exists=true;
					}
				}		
		}
		if (exists==false)
			System.out.println("The amka or the am does not exists");
		ststud.close();
		stprof.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return exists;
}

public static void searchgrades() {
	try {
		String ams,kwdikos;
		Scanner input=new Scanner(System.in);
		Scanner input1=new Scanner(System.in);
		System.out.println("Please enter the am of the student and the course code");
		ams=input.next();
		kwdikos=input1.nextLine();
		PreparedStatement pst =conn.prepareStatement("select * from \"Register\",\"Student\" where am=? and course_code=? and amka=amka_stud");
		pst.setString(1,ams);
		pst.setString(2,kwdikos);
		ResultSet rs=pst.executeQuery();
		while (rs.next()) {
					System.out.println(ams+"|"+rs.getString(2)+"|"+rs.getString(4));
					}
			} catch (SQLException e) {
					e.printStackTrace();
    }
}

public static void updategrade() {
	try {
		String ams,kwdikos;
		int grade;
		Scanner input=new Scanner(System.in);
		Scanner input1=new Scanner(System.in);
		Scanner input2=new Scanner(System.in);
		System.out.println("Please enter the am of the student and the course code and the new grade");
		ams=input.next();
		kwdikos=input1.nextLine();
		grade=input2.nextInt();
		String updateTableSQL = "Update \"Register\" "
				+ "SET final_grade=? "
				+ "From \"Student\" "
				+ "where \"Student\".am=? and \"Student\".amka=\"Register\".amka_stud and \"Register\".course_code=?";
		PreparedStatement pst1 =conn.prepareStatement(updateTableSQL);
		pst1.setInt(1,grade);
		pst1.setString(2,ams);
		pst1.setString(3,kwdikos);
        pst1.executeUpdate();
        db_commit();
			} catch (SQLException e) {
					e.printStackTrace();
    }
}

public static void searchperson(){
	try{
		String names;
		ResultSet surname;
		Scanner input=new Scanner(System.in);
		System.out.println("Please enter the first letters of the surname you want to search");
		names=input.next();
		PreparedStatement sur =conn.prepareStatement("select * from \"Person\" where left(\"Person\".surname,?)=?");
		//Statement sur=conn.createStatement();
		sur.setInt(1,names.length());
		sur.setString(2, names);
		surname=sur.executeQuery();
		while (surname.next()) {
			System.out.println(surname.getString(1)+"|"+surname.getString(2)+"|"+surname.getString(3)+"|"+surname.getString(4)+"|"+surname.getString(5));
			}
		
	
	}
	catch (SQLException e){
		e.printStackTrace();
	}
}




public static void searchgradesall() {
	try {
		String ams,kwdikos;
		Scanner input=new Scanner(System.in);
		System.out.println("Please enter the am of the student and the course code");
		ams=input.next();
		PreparedStatement pst =conn.prepareStatement("select * from \"Register\",\"Student\" where am=? and amka=amka_stud and (register_status='Pass' or register_status='Fail')");
		pst.setString(1,ams);
		ResultSet rs=pst.executeQuery();
		while (rs.next()) {
					System.out.println(ams+"|"+rs.getString(2)+"|"+rs.getString(4));
					}
			} catch (SQLException e) {
					e.printStackTrace();
    }
}

}
