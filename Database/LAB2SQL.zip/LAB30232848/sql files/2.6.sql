﻿CREATE OR REPLACE FUNCTION erwtima2_6()
RETURNS TABLE (kati bigint ,am varchar(10) )AS

$$
BEGIN
RETURN QUERY
select count(register_status),"Student".am 
from "Register","Student","Course"
where register_status='Pass' and "Register".amka_stud="Student".amka and "Course".course_code="Register".course_code and "Course".obligatory='True' and "Student".year<=2012
Group by "Student".am
having count(register_status)>34 
union
select count(register_status),"Student".am
from "Register","Student","Course"
where register_status='Pass' and "Register".amka_stud="Student".amka and "Course".course_code="Register".course_code and "Course".obligatory='False' and "Student".year<=2012
Group by "Student".am
having count(register_status)>15
order by am;

END;

$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT ERWTIMA2_6();