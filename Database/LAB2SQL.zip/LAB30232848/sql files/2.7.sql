﻿CREATE OR REPLACE FUNCTION erwtima2_7()
RETURNS TABLE(sum bigint)  AS 
$$
BEGIN
RETURN QUERY
Select sum(lab_hours)
From "Course","LabStaff"
where "LabStaff".lab_course= left(course_code,3)
Group by amka;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;


select erwtima2_7();