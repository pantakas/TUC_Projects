﻿CREATE OR REPLACE FUNCTION erwtima2_8 (coursecode varchar(10))
RETURNS TABLE (courcode character(7),coursetitle character(100)) AS
$$
BEGIN
return query
select course_code,course_title
from "Course","Course_depends"
where coursecode="Course_depends".dependent and "Course_depends".main="Course".course_code;

end;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT erwtima2_8('ΕΝΕ 301');

