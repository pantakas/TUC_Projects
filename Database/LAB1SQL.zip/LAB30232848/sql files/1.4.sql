﻿CREATE TABLE "Diploma"(
am_stud varchar ,
amka_com1 varchar,
amka_com2 varchar,
amka_com3 varchar,
diploma_num integer,
thesis_grade integer,
thesis_title varchar,
diploma_grade varchar,
graduation_date varchar,

FOREIGN KEY(amka_com1) references "Person"(amka),
FOREIGN KEY(amka_com2) references "Person"(amka),
FOREIGN KEY(amka_com3) references "Person"(amka)
);

--CREATE SEQUENCE diploma;

CREATE OR REPLACE FUNCTION insertdiploma(am_stud varchar,amka_com1 varchar,amka_com2 varchar,amka_com3 varchar) 
RETURNS VOID AS 
$$
BEGIN

INSERT INTO "Diploma"
SELECT distinct am_stud,amka_com1,amka_com2,amka_com3,nextval('diploma'),"Professor".lab_join,insertfield(amka_com1)
From "Student","Professor"
Where "Student".am=am_stud and "Student".year<=2012 and "Professor".amka=amka_com1 ;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION insertfield(amka_com1 varchar) 
RETURNS TABLE(tomeas varchar) AS 
$$
BEGIN
RETURN QUERY
SELECT  "Fields".field_code ::varchar
FROM "Fields","Professor","Lab_fields"
WHERE "Lab_fields".lab_code="Professor".lab_join and "Professor".amka=amka_com1
ORDER BY RANDOM() LIMIT 1;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT insertdiploma('2012004318','000009690','000009691','000009692');
SELECT insertdiploma('2012004337','000009695','000009693','000009692');
SELECT insertdiploma('2016004338','000009697','000009691','000009696');
SELECT insertdiploma('2012004344','000009697','000009691','000009696');