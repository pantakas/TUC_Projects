﻿CREATE TABLE "Register"(
 amka_stud varchar(30),
 course_code varchar(10),
 register_status varchar(10),
 final_grade integer,
 exam_grade integer,
 lab_grade integer,
 FOREIGN KEY(amka_stud) references "Person"(amka),
 FOREIGN KEY(course_code) references "Course"(course_code)
);





CREATE OR REPLACE FUNCTION create_mathimata()
RETURNS VOID AS
$$
BEGIN

insert into "Register"
select amka,course_code,'Proposed',NULL,NULL,NULL
from "Student","Course"
where (2017-"Student".year ="Course".typical_year)  and "Course".obligatory=TRUE and "Student".year!=2012 and "Course".typical_season='spring'
Order by amka;
 
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT create_mathimata();

CREATE OR REPLACE FUNCTION create_mathimata()
RETURNS VOID AS
$$
BEGIN

insert into "Register"
select amka,course_code,'Pass',random()*5+5,NULL,NULL
from "Student","Course"
where "Course".obligatory=TRUE and "Student".year=2012
Order by amka;
 
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION check_mathimata()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET register_status='Requested'
FROM "Course_depends","Course"
WHERE ("Register".course_code="Course".course_code and "Course".typical_year!=1) and ("Register".course_code="Course_depends".dependent and "Course_depends".mode='required');  -- ("Course_depends".mode='required' and "Register".course_code = "Course_depends".dependent and "Register".register_status='Pass' and "Course_depends".main="Register".course_code); 


END;
$$
LANGUAGE 'plpgsql' VOLATILE;



CREATE OR REPLACE FUNCTION checkproposed()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET register_status='Approved'
WHERE "Register".register_status='Proposed';

END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION checkrequested()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET register_status='Rejected'
WHERE "Register".register_status='Requested';

END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION create_approved()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET exam_grade=random()*9+1
WHERE "Register".register_status='Approved';

END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION create_lab_bathmo()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET lab_grade=random()*9+1
FROM "Course"
WHERE "Course".lab_hours!=0 and "Register".course_code="Course".course_code and "Register".register_status='Approved';

END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION create_final_bathmo()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET final_grade = exam_grade*0.7 + lab_grade*0.3
WHERE "Register".lab_grade is not NULL and "Register".register_status='Approved' and lab_grade>=5 and exam_grade>=5; 

END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION create_final_bathmo2()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET final_grade = exam_grade
WHERE "Register".lab_grade is NULL and "Register".register_status='Approved';

END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION createpass()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET register_status = 'Pass'
WHERE "Register".final_grade>=5 and "Register".register_status='Approved';

END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION createfail()
RETURNS VOID AS
$$
BEGIN

UPDATE "Register"
SET register_status = 'Fail'
WHERE ("Register".final_grade<5 or "Register".final_grade is NULL) and "Register".register_status='Approved' ;

END;
$$
LANGUAGE 'plpgsql' VOLATILE;


CREATE OR REPLACE FUNCTION apofoitoi()
RETURNS VOID AS
$$
BEGIN


insert into "Register"
select amka,course_code,'Pass',random()*5+5,NULL,NULL
from "Student","Course"
where  "Student".year=2012
Order by amka;

END;
$$
LANGUAGE 'plpgsql' VOLATILE;




SELECT check_mathimata();
SELECT checkproposed();
SELECT checkrequested();
SELECT bathmologia();
SELECT apofoitoi();
SELECT create_approved();
SELECT create_lab_bathmo();
SELECT create_final_bathmo();
SELECT create_final_bathmo2();
SELECT createpass();
SELECT createfail();
SELECT *
FROM "Register"
order by course_code;