﻿CREATE OR REPLACE FUNCTION search_student_by_coursecode(title varchar (7))
RETURNS TABLE (name varchar(30),surname varchar(30),am varchar(10)) AS
$$
BEGIN
   RETURN QUERY
   SELECT DISTINCT "Person".name,"Person".surname,"Student".am ::varchar  
   FROM "Person","Student","Register","Course"
   where "Person".amka="Student".amka and "Register".amka_stud="Student".amka and "Register".course_code=title and "Register".register_status!='Rejected' and "Register".register_status!='Proposed' ;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT search_student_by_coursecode('ΤΗΛ 201');