﻿CREATE OR REPLACE FUNCTION random_bathmos_diplwmatos()
RETURNS VOID AS
$$
BEGIN
  UPDATE "Diploma"
  SET diploma_grade=trunc(random()*5+5)
  WHERE "Diploma".diploma_grade IS NULL;
END;
$$
LANGUAGE 'plpgsql' VOLATILE; 

select random_bathmos_diplwmatos();
