﻿CREATE OR REPLACE FUNCTION updatepass() 
RETURNS TRIGGER AS $$ 
BEGIN
	UPDATE "Register"  SET final_grade=NEW.exam_grade*0.7+NEW.lab_grade*0.3 ;
        UPDATE "Register"  SET register_status='PASS';
	RETURN NEW;
END;
$$ LANGUAGE plpgsql; 


CREATE OR REPLACE FUNCTION updatefail() 
RETURNS TRIGGER AS $$ 
BEGIN
	UPDATE "Register"  SET telikos_bathmos=NULL ;
        UPDATE "Register"  SET register_status='FAIL';
	RETURN NEW;
END;
$$ LANGUAGE plpgsql; 

CREATE TRIGGER check_Student_update 
AFTER UPDATE OF final_grade ON "Register" 
FOR EACH ROW 
WHEN (NEW.exam_grade >5  and NEW.lab_grade > 5)
EXECUTE PROCEDURE updatepass();

CREATE TRIGGER check_Student_update2
AFTER UPDATE OF final_grade ON "Register" 
FOR EACH ROW 
WHEN (NEW.exam_grade <5  or NEW.lab_grade < 5)
EXECUTE PROCEDURE updatefail();