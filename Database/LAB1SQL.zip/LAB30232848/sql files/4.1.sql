﻿CREATE VIEW kathigites_view AS 
SELECT name,surname,course_code,course_title
FROM "Person"
NATURAL JOIN "Professor"
NATURAL JOIN "Course"
Where "Professor".amka="Person".amka and "Professor".course_join="Course".course_code