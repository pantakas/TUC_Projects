﻿CREATE TABLE "Semester"(
     semester_id varchar,
     academic_year integer,
     academic_season varchar,
     start_date date,
     semester_status varchar,
     end_date date,
     PRIMARY KEY (semester_id)
     );


--CREATE SEQUENCE Sem_ID;

INSERT INTO "Semester"
SELECT nextval('Sem_ID'),2017,'spring','2017-2-27','Present','2017-3-27';


CREATE OR REPLACE FUNCTION semester_insert()  RETURNS trigger AS
$$
BEGIN
	
	IF (TG_OP = 'INSERT') THEN
                 IF(NEW.start_date>(select "Semester".end_date from "Semester"  order by "Semester".end_date desc limit 1)) THEN
			   NEW.semester_status='Future';
			   RETURN NEW;
		 ELSE
			   RETURN NULL;
		 END IF;
			
	END IF;
END;
$$
LANGUAGE 'plpgsql';


CREATE OR REPLACE FUNCTION semester_update()  RETURNS trigger AS
$$
BEGIN
	
	UPDATE "Semester" SET semester_status='Past' WHERE "Semester".end_date<now()::date;
	UPDATE "Semester" SET semester_status='Present' WHERE "Semester".start_date<=now()::date and "Semester".end_date>now()::date;
	UPDATE "Semester" SET semester_status='Future' WHERE "Semester".start_date>now()::date;
	RETURN NEW;
END;
$$
LANGUAGE 'plpgsql';


CREATE TRIGGER semester_monitor1 BEFORE INSERT ON "Semester"
FOR EACH ROW EXECUTE PROCEDURE semester_insert();


CREATE TRIGGER semester_monitor2 AFTER INSERT ON "Semester"
FOR EACH ROW WHEN (NEW.semester_id!='-1')   EXECUTE PROCEDURE semester_update();


INSERT INTO "Semester"
SELECT nextval('Sem_ID'),2017,'spring','2017-4-27','','2017-4-28';




INSERT INTO "Semester"
SELECT nextval('Sem_ID'),2017,'spring','2017-4-27','','2017-4-28';

INSERT INTO "Semester"
SELECT nextval('Sem_ID'),2017,'spring','2017-8-27','','2017-8-28';


INSERT INTO "Semester"
SELECT nextval('Sem_ID'),2017,'spring','2017-9-27','','2017-9-28';


INSERT INTO "Semester"
SELECT nextval('Sem_ID'),2017,'spring','2017-10-27','','2017-10-28';

INSERT INTO "Semester"
SELECT nextval('Sem_ID'),2017,'spring','2018-4-27','','2018-4-28';