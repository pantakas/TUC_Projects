﻿

--2.5
select max(thesis_title) as high from "Diploma";