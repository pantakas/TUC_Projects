﻿CREATE OR REPLACE FUNCTION findpeople()
RETURNS TABLE(name varchar(30),surname varchar(30),idiotita varchar) AS
$$
BEGIN
RETURN QUERY

SELECT "Person".name,"Person".surname,'Professor'::varchar
FROM "Person","Professor"
WHERE "Professor".amka="Person".amka
UNION ALL
SELECT "Person".name,"Person".surname,'Labstaff' ::varchar
FROM "Person","LabStaff"
WHERE "LabStaff".amka="Person".amka
UNION ALL
SELECT "Person".name,"Person".surname,'Student' ::varchar
FROM "Person","Student"
WHERE "Student".amka="Person".amka;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT findpeople();

