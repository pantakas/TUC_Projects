﻿--------------an den trexei allakse ta hs os sto fathername gt den ta pairnei epeidh einai elliniko----------------------------
CREATE TABLE "Person"(
    name varchar(30),
    surname varchar(30),
    fathname varchar(30),
    amka varchar(30) NOT NULL,
    email varchar(100),
    PRIMARY KEY (amka)
);

--Function to create am--
CREATE OR REPLACE FUNCTION create_am(n integer)
RETURNS TABLE (amka varchar(30)) AS
$$
BEGIN
RETURN QUERY SELECT concat(trunc(random()*5+2012),lpad(nextval('am_SEQ')::text,6,'0')) ::varchar;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;  

--Function to create amka--
CREATE OR REPLACE FUNCTION create_amka(n integer)
RETURNS TABLE (am varchar(30)) AS
$$
BEGIN 
RETURN QUERY SELECT (lpad(nextval('amka_SEQ')::text,9,'0') ::text):: varchar
FROM generate_series(1,n);
END;
$$
LANGUAGE 'plpgsql' VOLATILE; 


--Function to create random fathnames--
CREATE OR REPLACE FUNCTION random_fathname(n integer)
RETURNS TABLE(fathname varchar(30)) AS
$$
BEGIN
  RETURN QUERY
  SELECT fath.name ::varchar
  FROM  (SELECT "Name".name 
	 FROM "Name"
	 WHERE right("Name".name,2)='ΟΣ' OR right("Name".name,2)='ΗΣ'
         ORDER BY random() LIMIT n) as fath ; 
END;
$$
LANGUAGE 'plpgsql' VOLATILE; 


--Function to create random names--
CREATE OR REPLACE FUNCTION random_names(n integer)
RETURNS TABLE(name varchar(30)) AS
$$
BEGIN
 RETURN QUERY
 SELECT nam.name ::varchar
 FROM (SELECT "Name".name
 FROM "Name"
 ORDER BY random() LIMIT n) as nam;
END;
$$
LANGUAGE 'plpgsql' VOLATILE; 

--Function to create random surnames--
CREATE OR REPLACE FUNCTION random_surnames(n integer)
RETURNS TABLE(surname varchar(30)) AS
$$
BEGIN
 RETURN QUERY
 SELECT sur.surname ::varchar
 FROM (SELECT "Surname".surname
 FROM "Surname"
 ORDER BY random() LIMIT n) as sur;
END;
$$
LANGUAGE 'plpgsql' VOLATILE; 


--Function to create email--
CREATE OR REPLACE FUNCTION create_email()
RETURNS TABLE (email varchar(100)) AS
$$
BEGIN
RETURN QUERY 
SElECT (concat(left("Person".name,1),"Person".surname,'@isc.tuc.gr') ::text)::varchar
FROM "Person";
 
END;
$$
LANGUAGE 'plpgsql' VOLATILE;


CREATE OR REPLACE FUNCTION insert_data(num integer)
RETURNS VOID AS
$$
BEGIN
	INSERT INTO "Person"
	SELECT  random_names(num),random_surnames(num),random_fathname(num),create_amka(num);
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT insert_data(100);
UPDATE "Person" set email=create_email();

------------------------CREATE STUDENT----------------------------------------------------------
CREATE TABLE "Student"(
   amka varchar(30) NOT NULL,
   am varchar(30) ,
   year integer,
   FOREIGN KEY (amka) REFERENCES "Person"(amka)
);


							--Function to Fill the requested Tables--
CREATE OR REPLACE FUNCTION insert_data_Student()
RETURNS VOID AS
$$
BEGIN
	INSERT INTO "Student"
	SELECT  import_amka(),create_am(20);
	
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION import_amka()
RETURNS TABLE (stud_amka varchar(30)) AS
$$
BEGIN
	RETURN QUERY
	SELECT  amka::varchar
	FROM "Person"
	LIMIT 60;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT insert_data_Student();


							--Function to create year--

CREATE OR REPLACE FUNCTION create_year()
RETURNS TABLE(year integer) AS
$$
BEGIN
RETURN QUERY  

select left("Student".am,4 )::integer
from "Student";
END;
$$
LANGUAGE 'plpgsql' VOLATILE; 

UPDATE "Student"  set year=create_year();
-------------------CREATE LABSTAFF------------------------------------------------------------------

CREATE TABLE "LabStaff"(
   amka varchar(30) NOT NULL,
   level character(1),
   FOREIGN KEY (amka)  REFERENCES "Person"(amka)
);


							--Function to Fill the requested Tables--
CREATE OR REPLACE FUNCTION insert_data_Labstaff()
RETURNS VOID AS
$$
BEGIN
	INSERT INTO "LabStaff"
	SELECT  import_amka_Labstaff(),create_level();
	
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

							--Function import  Labstaff's amka
CREATE OR REPLACE FUNCTION import_amka_Labstaff()
RETURNS TABLE (labstaff_amka varchar(30)) AS
$$
BEGIN
	RETURN QUERY
	SELECT  amka::varchar
	FROM "Person"
	LIMIT 20 OFFSET 60;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;
	


	
								--Function create  Labstaff's level
CREATE OR REPLACE FUNCTION create_level()
RETURNS TABLE (LF_level character(1)) AS
$$
BEGIN
	RETURN QUERY
	SELECT  ('[0:3]={A,B,C,D}'::text[])[trunc(random()*4)]::character(1);
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT insert_data_Labstaff();
------------------CREATE PROFESSOR-----------------------------------------------------

CREATE TABLE "Professor"(
   amka varchar(30) NOT NULL ,
   rank varchar(20),
   lab_join integer,
   course_join character(7),
   FOREIGN KEY (amka) REFERENCES "Person"(amka)
);

CREATE OR REPLACE FUNCTION insercoursejoin()
RETURNS TABLE (coursejoin character(7))AS
$$
BEGIN
RETURN QUERY
SELECT course_code
FROM (SELECT "Course".course_code
FROM "Course"
ORDER BY random() LIMIT trunc(random()+2)) as sur;
	
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

CREATE OR REPLACE FUNCTION insert_data_Professor()
RETURNS VOID AS
$$
BEGIN
	INSERT INTO "Professor"
	SELECT  import_amka_Professor(),create_rank(),insertlabjoin(),insercoursejoin();
	
END;
$$
LANGUAGE 'plpgsql' VOLATILE;
							--Function import  Professor's amka
CREATE OR REPLACE FUNCTION import_amka_Professor()
RETURNS TABLE (Proffesor_amka varchar(30)) AS
$$
BEGIN
	RETURN QUERY
	SELECT  amka::varchar
	FROM "Person"
	LIMIT 20 OFFSET 80;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;
	

CREATE OR REPLACE FUNCTION insertlabjoin()
RETURNS TABLE (labjoin integer)AS
$$
BEGIN
RETURN QUERY
SELECT lab_code
FROM (SELECT "Lab".lab_code
FROM "Lab"
ORDER BY random()) as sur;
	
END;
$$
LANGUAGE 'plpgsql' VOLATILE;
	
								--Function create  Professor's level
CREATE OR REPLACE FUNCTION create_rank()
RETURNS TABLE (Professor_level varchar(20)) AS
$$
BEGIN
	RETURN QUERY
	SELECT  ('[0:3]={full,associate,assistant,lecturer}'::text[])[trunc(random()*4)]::varchar;
END;
$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT insert_data_Professor();