﻿
CREATE OR REPLACE FUNCTION miperasmena (amkas varchar(30)) 
RETURNS TABLE(course_title character(100),course_code varchar(7)) AS
$$
BEGIN

RETURN QUERY
Select distinct "Course".course_title,"Course".course_code ::varchar
FROM "Course","Register","Student"
WHERE ("Student".amka="Register".amka_stud and "Student".amka=amkas and "Register".register_status!='Pass' and "Register".course_code="Course".course_code and "Course".obligatory=TRUE) or (2017-"Student".year<"Course".typical_year and "Course".obligatory=TRUE and "Student".amka="Register".amka_stud and "Student".amka=amkas)  ;

END;

$$
LANGUAGE 'plpgsql' VOLATILE;

SELECT miperasmena('000009610');
Select distinct "Course".course_title,"Course".course_code 
FROM "Course","Register","Student"
WHERE ("Student".amka="Register".amka_stud and "Student".amka='000009610' and "Register".register_status!='Pass' and "Register".course_code="Course".course_code and "Course".obligatory=TRUE) or (2017-"Student".year<"Course".typical_year and "Course".obligatory=TRUE and "Student".amka="Register".amka_stud and "Student".amka='000009610')  ;