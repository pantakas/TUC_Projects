package Employees;

public class Assistant extends General1{
	private String section;
	
	public Assistant(String name,int afm,String section){
		super(name,afm);
		this.section=section;
	}
	
	public String getSection(){return section;}
}
