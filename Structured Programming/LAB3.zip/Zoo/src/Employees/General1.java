package Employees;

public class General1{
	private String name;
	private int afm;
	
	public General1(String name,int afm){
		this.name=name;
		this.afm=afm;
	}
	
	public String getName(){return name;}
	public int getAfm(){return afm;}
}
