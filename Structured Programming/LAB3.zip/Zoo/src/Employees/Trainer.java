package Employees;

public class Trainer extends General1{
	private String kind;
	
	public Trainer(String name,int afm,String kind){
		super(name,afm);
		this.kind=kind;
	}
	
	public String getTraining(){return kind;}
}
