package Employees;

public class Empnode {
	protected Trainer info;
	protected Empnode next;
	protected Assistant info2;
	
	public Empnode(Trainer dat,Empnode b){
		this.info=dat;
		this.next=b;
	}
	public Empnode(Assistant dat,Empnode b){
		info2=dat;
		next=b;
	}
	public Trainer getTrainer(){return info;}
	public Assistant getAss(){return info2;}
	public void setNext(Empnode a){next=a;}
	public Empnode getNext(){return next;}
}
