package Employees;

public class Emplist {
	protected Empnode head;
	protected int length;
	
	public Emplist(){head=null; length=0;}
	public boolean IsEmpty(){return head==null;}
	
	
	public Empnode insert(Assistant a){
		length++;
		this.head=new Empnode(a,head);
		return head;
	}
	public Empnode insert(Trainer a){
		length++;
		this.head=new Empnode(a,head);
		return head;
	}
	
	public int getlength(){return length;}
}
