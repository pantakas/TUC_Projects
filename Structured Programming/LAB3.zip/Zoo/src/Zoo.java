import java.util.Scanner;

import Animals.*;
import Employees.*;
//��� ����������� ��������!
public class Zoo {
	public static void main(String[] args){
		String name="",location ="",help,help1,help2,help3;
		Anode head=null,head1=null,head2=null,temp=null;
		Empnode head3=null,head4=null,temp2=null;
		int answer,number,number1,i;
		Scanner in=new Scanner(System.in);
		Scanner init=new Scanner(System.in);
		Emplist listot=new Emplist(),listoa=new Emplist();
		Animlist listob=new Animlist(),listof=new Animlist(),listor=new Animlist();
		System.out.println("Welcome to the zoo!");
		do{answer=new Menu().getAnswer();
		switch(answer) {
						case 1:if(name.equals("")){
									System.out.println("Zoo name: ");
									name=in.nextLine();
									System.out.println("Location :");
									location=in.nextLine();}
								else
									System.out.println("You've already added the zoo!You can add only one zoo");
								break;
						case 2:if(name.equals("")) System.out.println("\nNo zoo added!");
								else System.out.println("\nZoo name : "+name+"\nLocation :"+location);
								if (listot.getlength()==0) System.out.println("\nNo trainers added!");
								else {temp2=head3; for (i=0;i<listot.getlength();i++){
							    	  System.out.println("\nName of employee :"+temp2.getTrainer().getName()+"\nAFM of employee :"+temp2.getTrainer().getAfm()+"\nKind of training :"+temp2.getTrainer().getTraining());     temp2=temp2.getNext();}}
								if(listoa.getlength()==0) System.out.println("\nNo assistants added!");
								else {temp2=head4; for(i=0;i<listoa.getlength();i++){
						    	      System.out.println("\nName of employee :"+temp2.getAss().getName()+"\nAFM of employee :"+temp2.getAss().getAfm()+"\nSection :"+temp2.getAss().getSection());  temp2=temp2.getNext();}}
								if(listob.getlength()==0) System.out.println("\nNo birds added!");
								else {temp=head; for(i=0;i<listob.getlength();i++){
									  System.out.println("\nName of the Bird :"+temp.getBirds().getName()+"\nSerial number of the animal :"+temp.getBirds().getSnumber()+"\nColour of its wings"+temp.getBirds().getCofwings());  temp=temp.getNext();}}
								if(listof.getlength()==0) System.out.println("\nNo fish added!");
								else {temp=head1; for(i=0;i<listof.getlength();i++){
									  System.out.println("\nName of the Fish :"+temp.getFish().getName()+"\nSerial number of the animal :"+temp.getFish().getSnumber()+"\nShape :"+temp.getFish().getShape()+"\nColour :"+temp.getFish().getColour()); temp=temp.getNext();}}
								if(listor.getlength()==0) System.out.println("\nNo reptiles added!");
								else {temp=head2; for(i=0;i<listor.getlength();i++){
									  System.out.println("\nName of the Reptile :"+temp.getRep().getName()+"\nSerial number of the animal :"+temp.getRep().getSnumber()+"\nBody type :"+temp.getRep().getBtype()); temp=temp.getNext();}}
								break;
						case 3:System.out.println("Do you want to add a Trainer or an Assistant");
							   do{help=in.nextLine(); if(!help.equals("Trainer")&&!help.equals("Assistant")) System.out.println("Not a valiable option");}while(!help.equals("Trainer")&&!help.equals("Assistant"));
							   if(help.equals("Trainer")){
							   System.out.println("Please give the name,the afm and the kind of training");
							   help=in.nextLine();
							   number=init.nextInt();
							   help2=in.nextLine();
							   head3=listot.insert(new Trainer(help,number,help2));}
							   else{
					           System.out.println("Please give the name,the afm and the section");
					           help=in.nextLine();
					           number=init.nextInt();
					           help2=in.nextLine();
					           head4=listoa.insert(new Assistant(help,number,help2));}
							   break;
						case 4:System.out.println("What kind of animal do you want to add?(Bird/Reptile/Fish)");
						       do{help=in.nextLine(); if(!help.equals("Bird")&&!help.equals("Reptile")&&!help.equals("Fish")) System.out.println("Not a valiable option\t Please try again");}while(!help.equals("Bird")&&!help.equals("Reptile")&&!help.equals("Fish"));
						       if(help.equals("Bird")){
						       System.out.println("Please give the name,the serial number and the colour of the bird");
						       help=in.nextLine();
						       number=init.nextInt();
						       help2=in.nextLine();
						       head=listob.insert(new Birds(help,number,help2));} 
						       else if(help.equals("Reptile")){
						       System.out.println("Does it have legs?(yes/no)");
						       do{help=in.nextLine(); if(!help.equals("yes")&&!help.equals("no")) System.out.println("Not a valiable option(yes/no)");}while(!help.equals("yes")&&!help.equals("no"));
						       if(help.equals("yes")) System.out.println("How many legs?");
						       else System.out.println("Enter highspeed of the reptile");
						       number1=init.nextInt();
						       System.out.println("Please give the name,the serial number and the body type of the reptile");
						       help1=in.nextLine();
						       number=init.nextInt();
						       help2=in.nextLine();
						       head1=listor.insert(new Reptiles(help1,number,help2,help,number1));}
						       else{System.out.println("Please give the name,the serial number,the body type and the colour of the fish");
						       help=in.nextLine();
						       number=init.nextInt();
						       help1=in.nextLine();
						       help2=in.nextLine();
						       head2=listof.insert(new Fish(help,number,help1,help2));}
						       break;
						case 5:System.out.println("Employees afm : ");
						       number=in.nextInt();
						       temp2=head3;
						       for (i=0;i<listot.getlength();i++){
						    	   if(number==temp2.getTrainer().getAfm()) System.out.println("\nName of employee :"+temp2.getTrainer().getName()+"\nAFM of employee :"+temp2.getTrainer().getAfm()+"\nKind of training :"+temp2.getTrainer().getTraining());
						    	   temp2=temp2.getNext();}
						       temp2=head4;
						       for(i=0;i<listoa.getlength();i++){
						    	   if(number==temp2.getAss().getAfm()) System.out.println("\nName of employee :"+temp2.getAss().getName()+"\nAFM of employee :"+temp2.getAss().getAfm()+"\nSection :"+temp2.getAss().getSection()); 
						    	   temp2=temp2.getNext();}
						       break;
						case 6:System.out.println("Animal's serial number : ");
							   number=in.nextInt();
							   temp=head;
							   for(i=0;i<listob.getlength();i++){
								   if (number==temp.getBirds().getSnumber()) System.out.println("\nName of the Bird :"+temp.getBirds().getName()+"\nSerial number of the animal :"+temp.getBirds().getSnumber()+"\nColour of its wings"+temp.getBirds().getCofwings()); 
								   temp=temp.getNext();}
							   temp=head1;
							   for(i=0;i<listof.getlength();i++){
								   if (number==temp.getFish().getSnumber())
								   System.out.println("\nName of the Fish :"+temp.getFish().getName()+"\nSerial number of the animal :"+temp.getFish().getSnumber()+"\nShape :"+temp.getFish().getShape()+"\nColour :"+temp.getFish().getColour()); 
								   temp=temp.getNext();}
							   temp=head2;
							   for(i=0;i<listor.getlength();i++){
								   if(number==temp.getRep().getSnumber())
								   System.out.println("\nName of the Reptile :"+temp.getRep().getName()+"\nSerial number of the animal :"+temp.getRep().getSnumber()+"\nBody type :"+temp.getRep().getBtype()); 
								   temp=temp.getNext();}
							   break;
						case 8:System.out.println("Do you want to see Trainers,Assistants,Birds,Reptiles or Fish?");
							   do{help=in.nextLine(); if(!help.equals("Bird")&&!help.equals("Reptile")&&!help.equals("Fish")&&!help.equals("Trainer")&&!help.equals("Assistant")) System.out.println("Not a valiable option!Please try again Caps needed");}while(!help.equals("Birds")&&!help.equals("Reptiles")&&!help.equals("Fish")&&!help.equals("Trainers")&&!help.equals("Assistants"));
							 
							   if(help.equals("Birds")){temp=head;
							   for(i=0;i<listob.getlength();i++){
								      System.out.println("\nName of the Bird :"+temp.getBirds().getName()+"\nSerial number of the animal :"+temp.getBirds().getSnumber()+"\nColour of its wings"+temp.getBirds().getCofwings()); 
								      temp=temp.getNext();}}
							   else if(help.equals("Fish")){temp=head1;
								   for(i=0;i<listof.getlength();i++){
									  System.out.println("\nName of the Fish :"+temp.getFish().getName()+"\nSerial number of the animal :"+temp.getFish().getSnumber()+"\nShape :"+temp.getFish().getShape()+"\nColour :"+temp.getFish().getColour()); 
									   temp=temp.getNext();}}
							   else if(help.equals("Reptiles")){temp=head2;
								   for(i=0;i<listor.getlength();i++){
									  System.out.println("\nName of the Reptile :"+temp.getRep().getName()+"\nSerial number of the animal :"+temp.getRep().getSnumber()+"\nBody type :"+temp.getRep().getBtype()); 
									   temp=temp.getNext();}}
							   else if(help.equals("Trainers")){temp2=head3;
							   	   for (i=0;i<listot.getlength();i++){
						    	      System.out.println("\nName of employee :"+temp2.getTrainer().getName()+"\nAFM of employee :"+temp2.getTrainer().getAfm()+"\nKind of training :"+temp2.getTrainer().getTraining());
						    	      temp2=temp2.getNext();}}
							   else if (help.equals("Assistants")){temp2=head4;
							   		for(i=0;i<listoa.getlength();i++){
						    	      System.out.println("\nName of employee :"+temp2.getAss().getName()+"\nAFM of employee :"+temp2.getAss().getAfm()+"\nSection :"+temp2.getAss().getSection()); 
						    	      temp2=temp2.getNext();}}
							   break;
		}
	 }while(answer!=9);
	}
}
