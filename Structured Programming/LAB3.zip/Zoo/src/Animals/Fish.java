package Animals;

public class Fish extends General{
	String shape,colour;
	
	public Fish(String name,int snumber,String shape,String colour){
		super(name,snumber);
		this.shape=shape;
		this.colour=colour;
	}
	
	public String getShape(){return shape;}
	public String getColour(){return colour;}
}
