package Animals;

public class Animlist {
	protected Anode head;
	protected int length;
	
	public Animlist(){head=null; length=0;}
	public boolean isEmpty(){return head==null;}
	
	public Anode insert(Birds a){
		length++;
		this.head=new Anode(a,head);
		return head;
	}
	public Anode insert(Fish a){
		length++;
		this.head=new Anode(a,head);
		return head;
	}
	public Anode insert(Reptiles a){
		length++;
		this.head=new Anode(a,head);
		return head;
	}
	public int getlength(){return length;}
}
