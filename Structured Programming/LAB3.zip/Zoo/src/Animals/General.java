package Animals;

public class General {
	private String name;
	private int snumber;
	
	public General(String name,int snumber){
		this.name=name;
		this.snumber=snumber;
	}
	
	public String getName(){return name;}
	public int getSnumber(){return snumber;}
	}

