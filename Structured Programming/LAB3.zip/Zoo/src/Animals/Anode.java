package Animals;

public class Anode {
	protected Birds info;
	protected Fish info1;
	protected Reptiles info2;
	protected Anode next;
	
	public Anode(Birds dat,Anode b){
		info=dat;
		this.next=b;}
	
	public Anode(Fish dat,Anode b){
		info1=dat;
		this.next=b;}
	
	public Anode(Reptiles dat,Anode b){
		info2=dat;
		this.next=b;}
	
	public Birds getBirds(){return info;}
	public Fish getFish(){return info1;}
	public Reptiles getRep(){return info2;}
	public void setNext(Anode a){next=a;}
	public Anode getNext(){return next;}
}
