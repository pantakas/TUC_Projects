package Animals;

public class Birds extends General{
	private String name,cofwings;
	private int serialnumber;
	
	public Birds(String name,int serialnumber,String cofwings){
		super(name,serialnumber);
		this.cofwings=cofwings;
	}
	
	public String getCofwings(){return cofwings;}
}
