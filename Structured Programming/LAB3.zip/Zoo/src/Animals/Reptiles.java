package Animals;

public class Reptiles extends General {
		private String btype,legs;
		private int third;
		
		public Reptiles(String name,int snumber,String btype,String legs,int third){
			super(name,snumber);
			this.btype=btype;
			this.legs=legs;
			this.third=third;
		}
		
		public String getBtype(){return btype;}
		public String getLegs(){return legs;}
		public int third(){return third;}
}
