import java.util.Scanner;


public class Menu {
	int answer;
	Scanner in=new Scanner(System.in);
	public Menu(){
		System.out.println("\nPress : \n1)To add the zoo\n2)To check zoo/employees/animals(info)\n3)To enter an employee\n4)To enter an animal\n5)To find an employee(via AFM)\n6)To find an animal(via Serial Number)\n7)To choose animals or employees you want to see\n8)To delete an animal\n9)Exit");
		do{answer=in.nextInt();
		if (answer<1||answer>9) System.out.println("Please choose one valiable option");}while(answer<1||answer>9);
	}
	public int getAnswer(){return answer;}
}
