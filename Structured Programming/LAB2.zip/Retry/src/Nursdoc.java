//���������� �����
//2013030010

import java.util.*;
import java.text.*;
import java.util.Scanner;

public class Nursdoc {
	   private String hospital;
	   private String doctor;
       private String patient;
       private Date inD,outD;
       private String[] hospexams;
       private Date[] datexams;

      
	   public Nursdoc(String Hospital,String[] Hospexams,Date[] Datexams,String Doctor,String Patient,Date InD,Date OutD){
		   hospital=Hospital;
		   hospexams=Hospexams;
		   datexams=Datexams;
		   doctor=Doctor;
		   patient=Patient;
		   inD=InD;
		   outD=OutD;
	   }
	   public String GetHosp(){
		   return hospital;
	   }
	   public String GetDoc(){
		   return doctor;
	   }
	   public String GetPat(){
		   return patient;
	   }
	   public String[] Getxams(){
		   return hospexams;
	   }
	   public Date GetInD(){
		   return inD;
	   }
	   public Date GetOutD(){
		   return outD;
	   }
	   public Date[] GetDxams(){
		   return datexams;
	   }
	   public void printall(){
		   System.out.println("\n\nHospital :"+hospital + "\nDoctor :"+doctor+"\nPatient :"+patient+"\ndate in :"+inD+"\ndate out :"+outD);
		   for (int i=0;hospexams[i]!=null;i++){
			   System.out.println("Exam :"+hospexams[i]+"\t Date :"+datexams[i]);
		   }
	   }
     }

