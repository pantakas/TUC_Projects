//���������� �����
//2013030010

import java.util.Scanner;

public class Hospital {
     private String hname;
     private String[] sections;
     
     String answer;
     public Hospital(String Hname,String Sections[]){
    	 hname=Hname;
    	 sections=Sections;
      }
     public String getName(){
    	 return hname;
     }
     public String[] getSections(){
    	 return sections;
     }
     
}
