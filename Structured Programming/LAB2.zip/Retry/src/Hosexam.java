//���������� �����
//2013030010

import java.util.Random;

public class Hosexam {
	private String hename;
	private int hecode;
	
	public Hosexam(String Hename){
		hename=Hename;
	}
	public void setCode(){
        Random rand=new Random();
    	int finish=rand.nextInt(1000);
    	hecode=finish;
	}
	public String getName(){
		return hename;
	}
	public int getCode(){
		return hecode;
	}
}
