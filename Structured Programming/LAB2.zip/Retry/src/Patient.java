//���������� �����
//2013030010

public class Patient {
       private String pname;
       private long amka;
       
       public Patient(String Pname,long Amka){
    	   pname=Pname;
    	   amka=Amka;
       }
       public String getPname(){
    	   return pname;
       }
       public long getAmka(){
    	   return amka;
       }
}
