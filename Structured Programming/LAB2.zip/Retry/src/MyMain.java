//���������� �����
//2013030010

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class MyMain {
	public static void main(String[] args) throws ParseException{
		DateFormat format = new SimpleDateFormat("dd.mm.yyyy");
		String help=null,help1,help2 = null,help3,help4,help5 = null;
		String[] array=new String[100];
		int answer,epilogh,j;
		Date[] datexams=new Date[5];
		Date datein=null,dateout=null;
		long amka=0;
		int[] i={0,0,0,0,0};
		boolean exist;
		Scanner temp=new Scanner(System.in);
		Scanner temp2=new Scanner(System.in);
		Scanner temp3=new Scanner(System.in);
		Hospital[] hosps=new Hospital[2];
		Hosexam[] exams=new Hosexam[100];
		Patient[] patients=new Patient[100];
		Doctor[] docs=new Doctor[100];
		Nursdoc[] ndocs=new Nursdoc[100];
	    System.out.println("1.Enter hospital data.\n2.Enter examination\n3.Enter a doctor.\n4.Enter a patient.\n5.Enter nursing documentation.\n6.Delete a patient.\n7.Find a nursing documentation.\n8.Print (doctors,patients etc).\n9.To exit!\nPlease choose one valiable option :");
	    answer=temp.nextInt();
	    do{ exist=false;
	       switch (answer){
	         case 1 :if (i[0]<2){ 
	        	      System.out.println("Give the name of the hospital");
	                  help=temp2.nextLine();
	                  System.out.println("Give the sections of the hospital(type exit to stop) :");
                      help1=temp.nextLine();
	                  for(j=0;!help1.equals("exit");j++){
	                	  array[j]=help1;
                          help1=temp2.nextLine();}
	                  hosps[i[0]]=new Hospital(help,array);
	                  array=new String[100];
	                  i[0]++;}
	                 else
	                  System.out.println("You cant add more than 2 hospitals!");
	                  break;
	         case 2 : System.out.println("Please type the name of the examination") ;
	                  help=temp2.nextLine();
                      exams[i[1]]=new Hosexam(help);
                      exams[i[1]].setCode();
                      for (j=0;j<i[1];j++){
                    	  if (exams[j].getCode()==exams[i[1]].getCode())
                    	  {exams[i[1]].setCode();
                    	   j=0; } }
                      i[1]++;
                      break;
	         case 3 : System.out.println("Type doctor's name,his specialty and the hospital that he works");
	                  help=temp2.nextLine();
	                  help1=temp2.nextLine();
	                  while(exist!=true){
	                	  help2=temp2.nextLine();
	                	  for(j=0;j<i[0];j++){
	                		  if(help2.equals(hosps[j].getName()))
	                		    exist=true;}
                          if(exist==false)
		                	  System.out.println("Please enter a valid hospital");}
	                  docs[i[2]]=new Doctor(help,help1,help2);
	                  docs[i[2]].setCode();
	                  for (j=0;j<i[2];j++){
	                	  if (docs[j].getCode()==docs[i[2]].getCode()){
	                		  docs[i[2]].setCode();
	                		  j=0;}}
	                  i[2]++;
	                  break;
	         case 4 : System.out.println("Please enter patient's name and AMKA");
	                  help=temp2.nextLine();
                      amka=temp3.nextLong();
	                  for (j=0;j<i[3];j++){
	                	  if(amka==patients[j].getAmka())
	                	      {System.out.println("There is already a patient with the same AMKA please try again");
	                	       j=0;
	                	       amka=temp3.nextLong();}}
	                  patients[i[3]]=new Patient(help,amka);
	                  i[3]++;
	                  break;
	         case 5 : if(i[0]!=0 && i[1]!=0 && i[2]!=0 && i[3]!=0)
	                       { System.out.println("1.Enter hospital's name\n2.Enter examinations(and dates),type exit to stop\n3.Enter Doctor's name\n4.Enter patient's name(when he was hospitalized and when he was discharged)\n");
                             for(j=0;j<i[0];j++)
	                              System.out.println(hosps[j].getName());
                             while(exist!=true){
	                	     help=temp2.nextLine();
	                	     for(j=0;j<i[0];j++){
	                		       if(help.equals(hosps[j].getName()))
	                		         exist=true;}
                                   if(exist==false)
		                	       System.out.println("Please enter a valid hospital");}
                             exist=false;
	                         for(j=0;j<i[1];j++)
                                System.out.println(exams[j].getName());
	                         help1=temp2.nextLine();
	                         int k=0;
	                         while(exist==false && !help1.equals("exit") && k<5){
	                	           for(j=0;j<i[1];j++){
	                		           if(help1.equals(exams[j].getName()))
	                		              exist=true;}
                                   if(exist==false)
		                	          System.out.println("Please enter a valid examination");
                                   else
                        	           {array[k]=help1;
                        	            System.out.println("Now enter the date of the examination(dd.mm.yyyy)");
                        	            help3=temp2.nextLine();
                        	            datexams[k]=format.parse(help3);
                        	            k++;}
                            help1=temp2.nextLine();
                            exist=false;}
	                        k=0;
	                        for (j=0;j<i[2];j++){
	               		        if (help.equals(docs[j].getHosp()))
	               		             {System.out.println((j+1) + ".Doctor : " + docs[j].getDname());
	               		             k++;}
	                            }
	                        if (k==0){
	                        	System.out.println("There are no doctors working in the "+help+" please enter a doc first!");
	                        	break;}
	                        while(exist!=true){
                                help2=temp2.nextLine();
	                	    for(j=0;j<i[2];j++){
	                		  if(help2.equals(docs[j].getDname()))
	                		    exist=true;}
                              if(exist==false)
		                	     System.out.println("Please enter a valid doctor");}
	                        exist=false;
	                        for(j=0;j<i[3];j++){
	                        	System.out.println((j+1)+"."+patients[j].getPname());
	                        }
	                        while(exist!=true){
                                help5=temp2.nextLine();
	                	        for(j=0;j<i[3];j++){
	                		    if(help5.equals(patients[j].getPname()))
	                		        exist=true;}
                                if(exist==false)
		                	     System.out.println("The patients with the name :"+help5+"doenst exist,please try again");}
	                        System.out.println("Please enter the date that patient was hospitalized and the date that he was discharged(dd.mm.yyyy)");
	                        help3=temp2.nextLine();
	                        datein=format.parse(help3);
	                        help4=temp2.nextLine();
	                        dateout=format.parse(help4);
	                        ndocs[i[4]]=new Nursdoc(help,array,datexams,help2,help5,datein,dateout); 
	                        i[4]++;}
	               else
	            	   System.out.println("You have to enter hospitals,doctors,patients and examinations first");
                   break;
	         case 6: System.out.println("Please give the AMKA of the patient");
	                 amka=temp3.nextLong();
	                 for (j=0;j<i[3];j++)
	                       {if (amka==patients[j].getAmka()){
	                    	   help=patients[j].getPname();
	                    	   patients[j]=null;
	                           for (int m=j;m<i[3]-1;m++){
	                        	   patients[m]=patients[m+1];}
	                           patients[i[3]]=null;
	                           i[3]--;}}	                
	                 for (j=0;j<i[4];j++){
	                	 if (help.equals(ndocs[j].GetPat())){
	                		 ndocs[j]=null;
	                		 for (int m=j;m<i[4]-1;m++){
	                			 ndocs[j]=ndocs[j+1];}
	                		 j=0;
	                		 ndocs[i[4]]=null;
                             i[4]--;}}
                   break;
	       case 7: System.out.println("Press 1.if you want to find nursing documents through AMKA.\nPress 2.if you want to find nursing documents through dates.");
	                do{
	                 epilogh=temp.nextInt();
	                 if(epilogh!=1 && epilogh!=2) 
	                	 System.out.println("Please choose a valiable option");
	                 }while (epilogh!=1 && epilogh!=2);
	                if(i[4]!=0){ 
	                   if (epilogh==1){
	                	  System.out.println("Please type AMKA :");
	                	  amka=temp3.nextLong();
	                	  for (j=0;j<i[3];j++){
	                		  if (amka==patients[j].getAmka())
	                			  help=patients[j].getPname();
	                	  }
	                	  System.out.println(ndocs[0].GetPat());
	                	  for (j=0;j<i[4];j++){
	                		  if (help.equals(ndocs[j].GetPat()))
	                			  ndocs[j].printall();
	                	  }
	            	      }
	                   else{
	                	  System.out.println("Enter the dates : ");
	                      help3=temp2.nextLine();
                          datein=format.parse(help3);
                          help4=temp2.nextLine();
                          dateout=format.parse(help4);
                          for (j=0;j<i[4];j++){
                        	if ((ndocs[j].GetInD()).after(datein) && (ndocs[j].GetInD()).before(dateout))
                        		ndocs[j].printall();}}
	                      }
	                else
	                	System.out.println("You have to add nursing documents first");
	                break;
	       case 8:if(i[0]!=0 && i[1]!=0 && i[2]!=0 && i[3]!=0 && i[4]!=0){
	    	          System.out.println("Press 1.Exams\tPress 2.Doctors\tPress 3.Patients\tPress 4.Nursing documents ");
	    	            do{
	    	             epilogh=temp.nextInt();
	    	             if (epilogh<1 || epilogh>4)
	    	            	 System.out.println("Please choose one valiable option");
	    	             }while(epilogh<1 || epilogh>4);
	    	          if (epilogh==1){
	    	        	  for (j=0;j<i[1];j++)
	    	        		  System.out.println("Exam :"+exams[j].getName()+"\t Code :"+exams[j].getCode());}
	    	          else if (epilogh==2){
	    	        	  for (j=0;j<i[2];j++)
	    	        		  System.out.println("Doctor :"+docs[j].getDname()+"\t Specialty :"+docs[j].getSpecialty()+"\t Hospital working:"+docs[j].getHosp()+"\tCode :"+docs[j].getCode());}
	    	          else if(epilogh==3){
	    	        	  for (j=0;j<i[3];j++)
	    	        		  System.out.println("Patient :"+patients[j].getPname()+"\t AMKA :"+patients[j].getAmka());}
	    	          else	{
	    	        	  for(j=0;j<i[4];j++)
	    	        		ndocs[j].printall();
	    	        	  System.out.println("\n\n\n");}
	    	          }
	               else
	            	 System.out.println("You have to enter doctors,patients,examinations and nursing documents first");
 	    }
	    System.out.println("What do you want to do now?");
	    answer=temp.nextInt();
	   }while (answer!=9);
	    System.gc();}	
}
