//���������� �����
//2013030010

import java.util.Random;

public class Doctor {
       private String dname,specialty,hospital;
       private int code;
       
       public Doctor(String Dname,String Specialty,String Hospital){
    	   dname=Dname;
    	   specialty=Specialty;
    	   hospital=Hospital;
       }
       public void setCode(){
    	   Random rand=new Random();
       	   int finish=rand.nextInt(1001);
       	   code=finish;
       }
       public String getDname(){
    	   return dname;
       }
       public String getSpecialty(){
    	   return specialty;
       }
       public int getCode(){
    	   return code;
       }
       public String getHosp(){
    	   return hospital;
       }
}
